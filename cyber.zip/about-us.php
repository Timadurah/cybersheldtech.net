<?php
require './header.php';
?>
<!-- main-area -->
<main class="main-area fix">

    <!-- breadcrumb-area -->
    <section class="breadcrumb-area">
        <div class="breadcrumb-bg" data-background="assets/img/bg/breadcrumb_bg.png"></div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-10">
                    <div class="breadcrumb-content text-center">
                        <h3 class="title">About Us</h3>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><br><a href="index">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">About Us</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb-area-end -->

    <!-- about-area -->
    <section class="about-area inner-about-padding">
    <div class="container">
        <!-- Introduction to Cyber Shield Tech -->
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="about-img">
                    <img src="assets/img/others/about1.png" alt="Cyber Shield Tech, a subsidiary of IT KART" style="border-radius: 10px;">
                </div>
            </div>
            <div class="col-lg-6 col-md-11">
                <div class="about-content">
                <br>    
                <h2 class="title">Cyber Shield Tech, a subsidiary of IT KART</h2>
                    <p>Cyber Shield Tech was established to provide cutting-edge cybersecurity solutions in Nigeria. As part of the globally recognized IT KART group, we are committed to delivering innovative IT services, including digital security, IT consulting, and infrastructure protection.</p>
                    <ul class="about-list">
                        <li>Cybersecurity solutions for businesses in Nigeria</li>
                        <li>Services: Digital security, IT consulting, and infrastructure protection</li>
                        <li>Delivering innovative IT services</li>
                    </ul>
                </div>
            </div>
        </div>
        
        <br /><br /><br /><br />

        <!-- Global Presence and Partnerships -->
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-11">
                    <div class="about-content">
                    <br>    
                    <h2 class="title">Global Presence and Partnerships</h2>
                        <p>Our parent company, IT KART, has a strong presence in India, Germany, the UK, the USA, and Australia, positioning us as a global leader in IT services. We are proud to partner with industry leaders such as Acronis, Microsoft, AWS, Tata Tele Services, MSP Alliance, Ingram, and CrowdStrike. These partnerships enable us to offer top-tier technology solutions and services to businesses around the world.</p>
                        <ul class="about-list">
                            <li>Presence in India, Germany, the UK, USA, and Australia</li>
                            <li>Partnerships with Acronis, Microsoft, AWS, and more</li>
                            <li>Access to advanced technology solutions for global clients</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about-img">
                        <img src="assets/img/others/Global-Presence.jpg" alt="Global Presence and Partnerships cyber security company">
                    </div>
                </div>
            </div>
        </div>

        <br /><br /><br />

        <!-- Expert Team with Global Certifications -->
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="about-img">
                        <img src="assets/img/others/about.png" alt="Expert Team with Global Certifications">
                    </div>
                </div>
                <div class="col-lg-6 col-md-11">
                    <div class="about-content">
                    <br>    
                    <h2 class="title">Expert Team with Global Certifications</h2>
                        <p>At IT KART and Cyber Shield Tech, we pride ourselves on the credibility and expertise of our global team. Our employees hold advanced industry certifications such as Certified Ethical Hacker (CEH), Offensive Security Certified Professional (OSCP), Acronis Professional, Microsoft Certified Engineers, Certified Penetration Testing Engineer, and AWS Certified. This ensures that our team is equipped with the highest level of skills and knowledge to address complex cybersecurity challenges.</p>
                        <ul class="about-list">
                            <li>Certified Ethical Hacker (CEH) and OSCP professionals</li>
                            <li>Certifications in Acronis, Microsoft, and AWS</li>
                            <li>Expertise in addressing complex cybersecurity challenges</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <br /><br /><br /><br />

        <!-- Strengthening Nigeria's Cybersecurity Landscape -->
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-11">
                    <div class="about-content">
                    <br>    
                    <h2 class="title">Strengthening Nigeria's Cybersecurity Landscape</h2>
                        <p>Through Cyber Shield Tech, we aim to strengthen the cybersecurity landscape for businesses in Nigeria by offering advanced technology solutions to protect their digital assets from evolving threats. Our goal is to ensure secure and resilient IT environments for our clients while driving innovation and growth across the region.</p>
                        <ul class="about-list">
                            <li>Advanced cybersecurity technology solutions for Nigerian businesses</li>
                            <li>Protection against evolving threats</li>
                            <li>Ensuring secure and resilient IT environments</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about-img">
                        <img src="assets/img/others/about2.jpeg" alt="Strengthening Nigeria's Cybersecurity Landscape">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--  -->
<section class="services-area inner-services-padding">
    <div class="container">
        <!-- Vulnerability Assessment and Penetration Testing Services -->
        <div class="row">
            <div class="col-12">
            <br>    
            <h2 class="title">Vulnerability Assessment and Penetration Testing Services</h2>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Web Application Penetration Testing</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Network Penetration Testing</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Wireless Penetration Testing</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Cloud Penetration Testing</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>IoT Penetration Testing</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Red Team Exercises</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Virtual CISO</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Dark Web Monitoring</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
        </div>

        <br /><br />

        <!-- Cyber Security Solutions -->
        <div class="row">
            <div class="col-12">
            <br>    
            <h2 class="title">Cyber Security Solutions</h2>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Advanced Security</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Advanced Security + EDR</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Advanced Security + XDR</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Advanced Security + MDR</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Advanced DLP</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Advanced Disaster Recovery</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Advanced Email Security</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Advanced Management</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Advanced File Sync and Share</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
        </div>

        <br /><br />

        <!-- Digital Forensics Services -->
        <div class="row">
            <div class="col-12">
            <br>    
            <h2 class="title">Digital Forensics Services</h2>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Computer Forensics</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Mobile Forensics</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Network Forensics</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Email Forensics</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Database Forensics</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="service-item"><br>
                    <h3>Data Recovery</h3>
                   <br> 
                    <a href="./contact.php" class="btn">Find out more</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!--  -->
    <!-- about-area-end -->

    <!-- fact-area -->
    <section class="fact-area inner-fact-padding">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-3 col-lg-4 col-sm-6">
                    <div class="fact-item"><br>
                    <br>    
                    <h2 class="count">
                            <span class="formatting-mark">+</span>
                            <span class="odometer" data-count="2164"></span>
                        </h2>
                        <span class="content">Global <br> Clientele</span>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-sm-6">
                    <div class="fact-item"><br>
                    <br>    
                    <h2 class="count">
                            <span class="formatting-mark">+</span>
                            <span class="odometer" data-count="120"></span>
                        </h2>
                        <span class="content">Cybersecurity <br> Professionals</span>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-sm-6">
                    <div class="fact-item"><br>
                    <br>    
                    <h2 class="count">
                            <span class="odometer" data-count="95"></span>
                            <span class="formatting-mark">%</span>
                        </h2>
                        <span class="content">Client <br> Retention Rate</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- fact-area-end -->

    <!-- team-area -->
    <section class="team-area team-bg about-team-padding">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-8 col-md-10">
                    <div class="section-title text-center mb-55">
                    <br>    
                    <h2 class="title">Our Expert Team: The Backbone of Your Cybersecurity</h2>
                    </div>
                </div>
            </div>
            <div class="team-wrapper">
                <div class="row justify-content-center justify-content-lg-between">
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="team-item"><br>
                            <div class="team-thumb">
                                <img style="height: 200px" src="assets/img/team/1.jpg" alt="img">
                            </div>
                            <div class="team-content">
                                <h4 class="name">Mr Rohit Kharat</h4>
                                <span class="designation">Cyber Security Expert & Advisor | vCISO | Cyber Crime Investigation | Police & Defence Trainer | Digital Forensics | Cyber Law. [ India ]</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="team-item"><br>
                            <div class="team-thumb">
                                <img style="height: 200px" src="assets/img/team/2.jpg" alt="img">
                            </div>
                            <div class="team-content">
                                <h4 class="name">Mr Alabamar Quadri</h4>
                                <span class="designation">Information Technology and Business Strategist. [ United States of America ]</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="team-item"><br>
                            <div class="team-thumb">
                                <img style="height: 200px" src="assets/img/team/3.jpg" alt="img">
                            </div>
                            <div class="team-content">
                                <h4 class="name">Mr Oluwafemi Temitope</h4>
                                <span class="designation"> Cyber Security Analyst | Digital Forensics Analyst | Penetration Tester | Certified Ethical Hacker. [ Nigeria ]</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="team-item"><br>
                            <div class="team-thumb">
                                <img style="height: 200px; width: 100%;" src="assets/img/team/4.png" alt="img">
                            </div>
                            <div class="team-content">
                                <h4 class="name">Mr Aduragbemi Ademola</h4>
                                <span class="designation">Software Engineer | API Developer | Full Stack Developer | Tech Solutions Architect | Database Management. [Nigeria]</span>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="team-btn text-center">
                        <a href="team" class="btn btn-style-two">
                            <span class="text">Join Our Team</span>
                            <span class="shape"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- team-area-end -->

    <!-- steps-area -->
    <section class="steps-area inner-steps-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-8 col-md-10">
                    <div class="section-title text-center mb-55">
                    <br>    
                    <h2 class="title">Secure Your Future in 3 Simple Steps</h2>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="steps-item text-center wow fadeInUp" data-wow-delay=".2s">
                        <div class="steps-img">
                            <img src="assets/img/others/steps_01.png" alt="img">
                        </div>
                        <div class="steps-content">
                            <h4 class="title">Select Your Security Package</h4>
                            <p>Evaluate our comprehensive offerings to find the perfect security solution tailored to your needs.</p>
                            <span class="steps-count">Step One</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="steps-item text-center wow fadeInUp" data-wow-delay=".4s">
                        <div class="steps-img">
                            <img src="assets/img/others/steps_02.png" alt="img">
                        </div>
                        <div class="steps-content">
                            <h4 class="title">Prepare for the Security Assessment</h4>
                            <p>Ensure your systems are ready for our in-depth security evaluation and penetration testing.</p>
                            <span class="steps-count">Step Two</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="steps-item text-center wow fadeInUp" data-wow-delay=".6s">
                        <div class="steps-img">
                            <img src="assets/img/others/steps_03.png" alt="img">
                        </div>
                        <div class="steps-content">
                            <h4 class="title">Review Your Personalized Security Plan</h4>
                            <p>Receive a detailed report outlining your vulnerabilities and our recommended solutions to enhance your security posture.</p>
                            <span class="steps-count">Step Three</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- steps-area-end -->

    <!-- marquee-area -->
    <div class="marquee-area">
        <div class="marquee-wrap">
            <span>We are always ready to protect your data</span>
            <span>We are always ready to protect your data</span>
            <span>We are always ready to protect your data</span>
            <span>We are always ready to protect your data</span>
            <span>We are always ready to protect your data</span>
            <span>We are always ready to protect your data</span>
        </div>
    </div>
    <!-- marquee-area-end -->


    <!-- testimonial-area-end -->

    <!-- blog-area -->
    <section class="blog-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-7 col-md-10">
                    <div class="section-title text-center mb-60">
                    <br>    
                    <h2 class="title">Elevate Your Career with Our Cybersecurity and Programming Certification Course</h2>
                        <p class="subtitle">Master the essential skills in cybersecurity and programming to thrive in today's digital landscape.</p>
                    </div>
                </div>
            </div>
            <div class="row blog-active">
                <div class="col-xl-3 ">
                    <div class="blog-post-item"><br>
                        <div class="blog-post-thumb">
                            <a href="blog-details.php">

                                <img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                        </div>
                        <div class="blog-post-content">
                            <h3 class="title"><a href="./studen_registration.php">Python from 0 to hero</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 ">
                    <div class="blog-post-item"><br>
                        <div class="blog-post-thumb">
                            <a href="blog-details.php">

                                <img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                        </div>
                        <div class="blog-post-content">
                            <h3 class="title"><a href="blog-details.php">Building Resilient Applications: Cybersecurity Fundamentals for Developers</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 ">
                    <div class="blog-post-item"><br>
                        <div class="blog-post-thumb">
                            <a href="blog-details.php">

                                <img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                        </div>
                        <div class="blog-post-content">
                            <h3 class="title"><a href="blog-details.php">Automating Cybersecurity: The Role of Scripting and Programming</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 ">
                    <div class="blog-post-item"><br>
                        <div class="blog-post-thumb">
                            <a href="blog-details.php">

                                <img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                        </div>
                        <div class="blog-post-content">
                            <h3 class="title"><a href="blog-details.php">Securing APIs: Best Practices for Developers</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 ">
                    <div class="blog-post-item"><br>
                        <div class="blog-post-thumb">
                            <a href="blog-details.php">
                                <img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                        </div>
                        <div class="blog-post-content">
                            <h3 class="title"><a href="blog-details.php">Understanding Cyber Threats: A Developer's Perspective</a></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- blog-area-end -->

</main>
<!-- main-area-end -->


<?php
require './footer.php';
?>