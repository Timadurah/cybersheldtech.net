 <!-- footer-start -->
 <footer class="footer-area footer-bg" data-background="assets/img/bg/footer_bg.jpg">
     <div class="container">
         <div class="footer-top-wrap">
             <div class="row justify-content-between">
                 <div class="col-xl-3 col-lg-4 col-sm-6">
                     <div class="footer-widget">
                         <div class="footer-contact-info">
                             <h4 class="number">+2349045193779</h4>
                             <h4 class="number">+91 848484 4985</h4>
                             <h4 class="email">contact@cybershieldtech.net</h4>
                             <p>Block 15,
                                 <br>Rd 34 Victoria Garden City Ikota Aja Lagos.
                             </p>
                             <ul class="footer-social list-wrap">
                                 <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                 <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                 <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                             </ul>
                         </div>
                     </div>
                 </div>
                 <div class="col-xl-2 col-lg-3 col-md-6 col-sm-4 column-2">
                     <div class="footer-widget">
                         <h4 class="fw-title">Quick Links</h4>
                         <ul class="footer-link">
                             <li><a href="about-us">About us</a></li>
                             <li><a href="srevices">Case Studies</a></li>
                             <li><a href="contact">Terms & Conditions</a></li>
                             <li><a href="contact">Privacy Poilicy</a></li>
                             <li><a href="contact">Contact Us</a></li>
                         </ul>
                     </div>
                 </div>
                 <div class="col-xl-2 col-lg-3 col-md-6 col-sm-4 column-3">
                     <div class="footer-widget">
                         <h4 class="fw-title">Our Services</h4>
                         <ul class="footer-link">
                             <li><a href="services">Spyware Protection</a></li>
                             <li><a href="services">Fast Cloud Backup</a></li>
                             <li><a href="services">Database Security</a></li>
                             <li><a href="services">Transaction Security</a></li>
                             <li><a href="services">Spambot Shield</a></li>
                         </ul>
                     </div>
                 </div>
                 <div class="col-xxl-4 col-xl-3 col-lg-4 col-md-6 col-sm-7">
                     <div class="footer-widget">
                         <form action="#" class="newsletter-form">
                             <div class="form-grp">
                                 <input type="email" required placeholder="Your email address">
                             </div>
                             <button type="submit" class="btn">Subscribe now <span class="shape"></span></button>
                             <p class="newsletter-alert"><span>*</span> Don't worry, we don't spam</p>
                         </form>
                     </div>
                 </div>
             </div>
         </div>
         <div class="copyright-wrap">
             <p class="copyright-text">Copyright ©2023 Design By <span> CYBERSHIELD TECH</span></p>
         </div>
     </div>
 </footer>
 <!-- footer-start-end -->



 <!-- JS here -->
 <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
 <script src="assets/js/bootstrap.min.js"></script>
 <script src="assets/js/jquery.magnific-popup.min.js"></script>
 <script src="assets/js/jquery.odometer.min.js"></script>
 <script src="assets/js/jquery.appear.js"></script>
 <script src="assets/js/particles.min.js"></script>
 <script src="assets/js/slick.min.js"></script>
 <script src="assets/js/ajax-form.js"></script>
 <script src="assets/js/wow.min.js"></script>
 <script src="assets/js/main.js"></script>
 </body>

 <!-- Mirrored from themedox.com/demo/cycure/index-3 by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 23 Sep 2024 21:50:46 GMT -->

 </html>