<?php
require './header.php';
?>

<!-- Main Content Area -->
<main class="main-area fix">

    <!-- Breadcrumb Section -->
    <section class="breadcrumb-area">
        <div class="breadcrumb-bg" data-background="assets/img/bg/breadcrumb_bg.png"></div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-10">
                    <div class="breadcrumb-content text-center">
                        <h3 class="title">Contact Us</h3>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Breadcrumb Section -->

    <!-- Contact Section -->
    <section class="contact-area">
        <div class="contact-info-wrapper">
            <div class="container">
                <div class="row justify-content-around">
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-8">
                        <div class="contact-info-item text-center">
                            <div class="contact-info-icon">
                                <i class="flaticon-chat"></i>
                            </div>
                            <div class="contact-info-content">
                                <h5 class="title">Chat With Us</h5>
                                <p>Connect with our knowledgeable support team, available Monday to Friday from 9 AM to 5 PM EST.</p>
                                <a href="#" class="contact-info-link">Start a Chat</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-8">
                        <div class="contact-info-item text-center">
                            <div class="contact-info-icon">
                                <i class="flaticon-open-mail"></i>
                            </div>
                            <div class="contact-info-content">
                                <h5 class="title">Send Us an Email</h5>
                                <p>For inquiries, please email us at <a href="mailto: info@cybershieldtech.net"> info@cybershieldtech.net</a>. Expect a response within 24 hours.</p>
                                <a href="mailto: info@cybershieldtech.net" class="contact-info-link">Email Us</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-8">
                        <div class="contact-info-item text-center">
                            <div class="contact-info-icon">
                                <i class="flaticon-phone"></i>
                            </div>
                            <div class="contact-info-content">
                                <h5 class="title">Make a Call</h5>
                                <p>For immediate assistance, call us at +91 848484 4985 or +2349045193779
                                    available Monday to Friday from 9 AM to 5 PM EST.</p>
                                <a href="tel:2349045193779" class="contact-info-link">Call Us</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="map" data-background="assets/img/bg/map.jpg"></div>
        <div class="contact-form-wrap">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-5 col-lg-7 col-md-9 col-sm-10">
                        <div class="section-title text-center mb-50">
                            <h2 class="title">Have Questions or Comments? Get in Touch</h2>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-xxl-8 col-xl-9 col-lg-10">
                        <?php
                        require './conf.php';

                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                            // Clean and validate form data
                            $name = htmlspecialchars(trim($_POST['name']));
                            $email = htmlspecialchars(trim($_POST['email']));
                            $message = htmlspecialchars(trim($_POST['message']));

                            // Prepare and bind the SQL statement
                            $stmt = $conn->prepare("INSERT INTO messages (name, email, message) VALUES (?, ?, ?)");
                            $stmt->bind_param("sss", $name, $email, $message);

                            // Execute the statement and check if the data was inserted successfully
                            if ($stmt->execute()) {
                                echo "Message sent successfully!";
                            } else {
                                echo "Error: " . $stmt->error;
                            }

                            // Close the statement and the connection
                            $stmt->close();
                        }

                        $conn->close();
                        ?>

                        <!-- Your HTML form -->
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" class="contact-form text-center">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-grp">
                                        <input type="text" name="name" id="name" required placeholder="Enter your full name">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-grp">
                                        <input type="email" name="email" id="email" required placeholder="Enter your email address">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-grp">
                                        <textarea name="message" id="message" required placeholder="Write your message..."></textarea>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn">Send Message</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Contact Section -->

</main>
<!-- End Main Content Area -->

<?php
require './footer.php';
?>