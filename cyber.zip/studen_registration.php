<?php
require './header.php';
?>

<!-- Main Content Area -->
<main class="main-area fix">

    <!-- Breadcrumb Section -->
    <section class="breadcrumb-area">
        <div class="breadcrumb-bg" data-background="assets/img/bg/breadcrumb_bg.png"></div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-10">
                    <div class="breadcrumb-content text-center">
                        <h3 class="title">Join Our Lecture</h3>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Join Now</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Breadcrumb Section -->

    <!-- Contact Section -->
    <section class="contact-area">
        <div class="contact-form-wrap">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-5 col-lg-7 col-md-9 col-sm-10">
                        <div class="section-title text-center mb-50">
                            <h2 class="title">Input Your Information</h2>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-xxl-8 col-xl-9 col-lg-10">
                        <?php
                        require './conf.php';
                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                            // Clean and validate form data
                            $name = htmlspecialchars(trim($_POST['name']));
                            $email = htmlspecialchars(trim($_POST['email']));
                            $phone = htmlspecialchars(trim($_POST['phone']));
                            $address = htmlspecialchars(trim($_POST['address']));

                            // Prepare and bind the SQL statement
                            $stmt = $conn->prepare("INSERT INTO contacts (name, email, phone, address) VALUES (?, ?, ?, ?)");
                            $stmt->bind_param("ssss", $name, $email, $phone, $address);

                            // Execute the statement and check if the data was inserted successfully
                            if ($stmt->execute()) {
                                echo "Rehisteration submit successfully!";
                            } else {
                                echo "Error: " . $stmt->error;
                            }

                            // Close the statement and the connection
                            $stmt->close();
                        }

                        $conn->close();
                        ?>

                        <!-- Your HTML form -->
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" class="contact-form text-center">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-grp">
                                        <input type="text" name="name" id="name" required placeholder="Enter your full name">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-grp">
                                        <input type="email" name="email" id="email" required placeholder="Enter your email address">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-grp">
                                        <input type="text" name="phone" id="phone" required placeholder="Enter your phone">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-grp">
                                        <input type="text" name="address" id="address" required placeholder="Enter your address">
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn">Send Message</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Contact Section -->

</main>
<!-- End Main Content Area -->

<?php
require './footer.php';
?>