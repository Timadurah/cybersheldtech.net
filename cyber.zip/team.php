<?php
require './header.php';
?>


<!-- main-area -->
<main class="main-area fix">

    <!-- breadcrumb-area -->
    <section class="breadcrumb-area">
        <div class="breadcrumb-bg" data-background="assets/img/bg/breadcrumb_bg.png"></div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-10">
                    <div class="breadcrumb-content text-center">
                        <h3 class="title">Our Team</h3>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Our Team</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb-area-end -->

    <!-- team-area -->
    <section class="team-area team-bg inner-team-padding">
        <div class="container">
            <div class="team-wrapper">
                <div class="row justify-content-center justify-content-lg-between">
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="team-item">
                            <div class="team-thumb">
                                <img style="height: 200px" src="assets/img/team/1.jpg" alt="img">
                            </div>
                            <div class="team-content">
                                <h4 class="name">Morgan Cooper</h4>
                                <span class="designation">CEO & Founder</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="team-item">
                            <div class="team-thumb">
                                <img style="height: 200px" src="assets/img/team/2.jpg" alt="img">
                            </div>
                            <div class="team-content">
                                <h4 class="name">Amanda Brown</h4>
                                <span class="designation">Co-Founder</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="team-item">
                            <div class="team-thumb">
                                <img style="height: 200px" src="assets/img/team/3.jpg" alt="img">
                            </div>
                            <div class="team-content">
                                <h4 class="name">Harry Peterson</h4>
                                <span class="designation">Head of Security</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="team-item">
                            <div class="team-thumb">
                                <img style="height: 200px" src="assets/img/team/4.png" alt="img">
                            </div>
                            <div class="team-content">
                                <h4 class="name">Aduragbemi Ademola</h4>
                                <span class="designation">Software Engineer</span>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="team-btn text-center">
                        <a href="contact" class="btn btn-style-two">
                            <span class="text">Join our team</span>
                            <span class="shape"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- team-area-end -->

</main>
<!-- main-area-end -->

<?php
require './footer.php';
?>