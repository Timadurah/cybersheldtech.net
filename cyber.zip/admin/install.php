<?php
// install.php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = $_POST['db_host'];
    $username = $_POST['db_user'];
    $password = $_POST['db_pass'];
    $dbname = $_POST['db_name'];
    $admin_user = $_POST['admin_user'];
    $admin_pass = password_hash($_POST['admin_pass'], PASSWORD_DEFAULT);

    // Create connection
    $conn = new mysqli($servername, $username, $password);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Create database
    $sql = "CREATE DATABASE IF NOT EXISTS $dbname";
    if ($conn->query($sql) === TRUE) {
        echo "Database created successfully<br>";
    } else {
        echo "Error creating database: " . $conn->error;
    }

    // Select the database
    $conn->select_db($dbname);

    // Create admin table
    $sql = "CREATE TABLE IF NOT EXISTS admin (
        id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL
    )";

    if ($conn->query($sql) === TRUE) {
        echo "Admin table created successfully<br>";
    } else {
        echo "Error creating table: " . $conn->error;
    }

    // Insert admin user
    $sql = "INSERT INTO admin (username, password) VALUES ('$admin_user', '$admin_pass')";
    if ($conn->query($sql) === TRUE) {
        echo "Admin user created successfully<br>";
    } else {
        echo "Error creating admin user: " . $conn->error;
    }

    // Create contacts table
    $sql = "CREATE TABLE IF NOT EXISTS contacts (
        id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        address VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";

    if ($conn->query($sql) === TRUE) {
        echo "Contacts table created successfully<br>";
    } else {
        echo "Error creating contacts table: " . $conn->error;
    }

    // Create messages table
    $sql = "CREATE TABLE IF NOT EXISTS messages (
        id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";

    if ($conn->query($sql) === TRUE) {
        echo "Messages table created successfully<br>";
    } else {
        echo "Error creating messages table: " . $conn->error;
    }

    // Close connection
    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install Admin Panel</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h3 class="text-center">Install Admin Panel</h3>
                <form method="POST" action="">
                    <h5>Database Settings</h5>
                    <div class="form-group">
                        <label for="db_host">Database Host</label>
                        <input type="text" name="db_host" id="db_host" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="db_name">Database Name</label>
                        <input type="text" name="db_name" id="db_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="db_user">Database User</label>
                        <input type="text" name="db_user" id="db_user" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="db_pass">Database Password</label>
                        <input type="password" name="db_pass" id="db_pass" class="form-control" required>
                    </div>
                    <h5>Admin Settings</h5>
                    <div class="form-group">
                        <label for="admin_user">Admin Username</label>
                        <input type="text" name="admin_user" id="admin_user" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="admin_pass">Admin Password</label>
                        <input type="password" name="admin_pass" id="admin_pass" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Install</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
<!-- 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install Admin System</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
    <h1>Install Admin System</h1>
    <form action="install.php" method="POST">
        <label for="db_host">Database Host:</label>
        <input type="text" id="db_host" name="db_host" required><br>

        <label for="db_user">Database User:</label>
        <input type="text" id="db_user" name="db_user" required><br>

        <label for="db_pass">Database Password:</label>
        <input type="password" id="db_pass" name="db_pass" required><br>

        <label for="db_name">Database Name:</label>
        <input type="text" id="db_name" name="db_name" required><br>

        <label for="admin_user">Admin Username:</label>
        <input type="text" id="admin_user" name="admin_user" required><br>

        <label for="admin_pass">Admin Password:</label>
        <input type="password" id="admin_pass" name="admin_pass" required><br>

        <button type="submit">Install</button>
    </form>
</body>
</html> -->
