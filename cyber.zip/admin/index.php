<?php
session_start();
require '../conf.php';
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: ./login.php");
    exit;
}

// Handle delete requests
if (isset($_GET['delete_message_id'])) {
    $id = intval($_GET['delete_message_id']);
    $conn->query("DELETE FROM messages WHERE id=$id");
} elseif (isset($_GET['delete_contact_id'])) {
    $id = intval($_GET['delete_contact_id']);
    $conn->query("DELETE FROM contacts WHERE id=$id");
}

// Fetch messages
$messages = $conn->query("SELECT * FROM messages ORDER BY created_at DESC");

// Fetch contacts
$contacts = $conn->query("SELECT * FROM contacts ORDER BY created_at DESC");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">


    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Meta Description -->
    <meta name="description" content="Cybershield Tech is a leading cybersecurity firm dedicated to delivering advanced solutions that safeguard businesses against cyber threats. Secure your data with our innovative protection strategies." />

    <!-- Meta Keywords -->
    <meta name="keywords" content="cybersecurity, cyber security firm, digital security, data protection, cyber threats, network security, online security, Cybershield Tech" />

    <!-- Meta Author -->
    <meta name="author" content="Cybershield Tech" />

    <!-- Meta Robots -->
    <meta name="robots" content="index, follow" />

    <!-- Open Graph Meta for Social Sharing -->
    <meta property="og:title" content="Cybershield Tech - Premier Cybersecurity Solutions" />
    <meta property="og:description" content="Cybershield Tech provides comprehensive cybersecurity services designed to protect your business from various cyber risks. Partner with us to secure your digital assets." />
    <meta property="og:image" content="https://yourwebsite.com/images/og-image.jpg" />
    <meta property="og:url" content="https://yourwebsite.com" />
    <meta property="og:type" content="website" />

    <!-- Twitter Card Meta -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="Cybershield Tech - Premier Cybersecurity Solutions" />
    <meta name="twitter:description" content="Enhance your business's security with expert cybersecurity solutions from Cybershield Tech. Our dedicated team ensures your data remains safe from cyber threats." />
    <meta name="twitter:image" content="https://yourwebsite.com/images/twitter-card-image.jpg" />

    <!-- Viewport Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />


    <!-- Favicon -->
    <link rel="icon" href="https://yourwebsite.com/favicon.ico" />
    <link rel="shortcut icon" type="image/x-icon" href="../assets/img/logo/logo.png">


</head>

<body>
    <center>
        <img src="../assets/img/logo/logo.png" alt="Cybersectech logo">
    </center>
    <div class="container mt-5">
        <h2 class="mb-4">Admin Panel - Manage Submissions</h2>

        <!-- Messages Table -->
        <h4>Message Submissions</h4>
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Message</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $messages->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['message']); ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                        <td>
                            <a href="?delete_message_id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <!-- Contacts Table -->
        <h4>Contact Submissions</h4>
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $contacts->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['phone']); ?></td>
                        <td><?php echo htmlspecialchars($row['address']); ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                        <td>
                            <a href="?delete_contact_id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>