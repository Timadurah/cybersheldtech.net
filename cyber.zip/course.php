<?php
require './header.php';
?>

<!-- main-area -->
<main class="main-area fix">

    <!-- breadcrumb-area -->
    <section class="breadcrumb-area">
        <div class="breadcrumb-bg" data-background="assets/img/bg/breadcrumb_bg.png"></div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-10">
                    <div class="breadcrumb-content text-center">
                        <h3 class="title">Course Page</h3>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Course Grid</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb-area-end -->

    <!-- course-area -->
    <section class="course-area inner-course-area">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-9">
                <div class="course-post-item">
                    <div class="course-post-thumb">
                        <a href="./studen_registration"><img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                    </div>
                    <div class="course-post-content">
                        <h3 class="title"><a href="./studen_registration">Top 5 Programming Languages to Learn in 2024</a></h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-9">
                <div class="course-post-item">
                    <div class="course-post-thumb">
                        <a href="./studen_registration"><img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                    </div>
                    <div class="course-post-content">
                        <h3 class="title"><a href="./studen_registration">Implementing Secure Coding Practices</a></h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-9">
                <div class="course-post-item">
                    <div class="course-post-thumb">
                        <a href="./studen_registration"><img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                    </div>
                    <div class="course-post-content">
                        <h3 class="title"><a href="./studen_registration">Understanding Cybersecurity Fundamentals</a></h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-9">
                <div class="course-post-item">
                    <div class="course-post-thumb">
                        <a href="./studen_registration"><img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                    </div>
                    <div class="course-post-content">
                        <h3 class="title"><a href="./studen_registration">The Importance of Penetration Testing</a></h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-9">
                <div class="course-post-item">
                    <div class="course-post-thumb">
                        <a href="./studen_registration"><img style="background-color: darkblue;" src="assets/img/logo/logo.png" alt="img"></a>
                    </div>
                    <div class="course-post-content">
                        <h3 class="title"><a href="./studen_registration">Choosing the Right Framework for Secure Applications</a></h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-9">
                <div class="course-post-item">
                    <div class="course-post-thumb">
                        <a href="./studen_registration"><img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                    </div>
                    <div class="course-post-content">
                        <h3 class="title"><a href="./studen_registration">Cybersecurity Best Practices for Developers</a></h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-9">
                <div class="course-post-item">
                    <div class="course-post-thumb">
                        <a href="./studen_registration"><img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                    </div>
                    <div class="course-post-content">
                        <h3 class="title"><a href="./studen_registration">How to Secure Your APIs</a></h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-9">
                <div class="course-post-item">
                    <div class="course-post-thumb">
                        <a href="./studen_registration"><img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                    </div>
                    <div class="course-post-content">
                        <h3 class="title"><a href="./studen_registration">The Future of Cybersecurity: Trends to Watch</a></h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-9">
                <div class="course-post-item">
                    <div class="course-post-thumb">
                        <a href="./studen_registration"><img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                    </div>
                    <div class="course-post-content">
                        <h3 class="title"><a href="./studen_registration">Data Privacy: Best Practices for Developers</a></h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-9">
                <div class="course-post-item">
                    <div class="course-post-thumb">
                        <a href="./studen_registration"><img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                    </div>
                    <div class="course-post-content">
                        <h3 class="title"><a href="./studen_registration">Essential Tools for Cybersecurity Professionals</a></h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-9">
                <div class="course-post-item">
                    <div class="course-post-thumb">
                        <a href="./studen_registration"><img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                    </div>
                    <div class="course-post-content">
                        <h3 class="title"><a href="./studen_registration">Getting Started with Ethical Hacking</a></h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-9">
                <div class="course-post-item">
                    <div class="course-post-thumb">
                        <a href="./studen_registration"><img style="background-color: blue;" src="assets/img/logo/logo.png" alt="img"></a>
                    </div>
                    <div class="course-post-content">
                        <h3 class="title"><a href="./studen_registration">AI in Cybersecurity: Opportunities and Challenges</a></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

    <!-- course-area-end -->
</main>
<!-- main-area-end -->
<br>
<br><br>
<br>
<?php
require './footer.php';
?>
