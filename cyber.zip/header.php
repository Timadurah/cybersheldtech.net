<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Cybershield Tech - Premier Cybersecurity Solutions</title>

    <!-- Meta Description -->
    <meta name="description" content="Cybershield Tech is a leading cybersecurity firm dedicated to delivering advanced solutions that safeguard businesses against cyber threats. Secure your data with our innovative protection strategies." />

    <!-- Meta Keywords -->
    <meta name="keywords" content="cybersecurity, cyber security firm, digital security, data protection, cyber threats, network security, online security, Cybershield Tech" />

    <!-- Meta Author -->
    <meta name="author" content="Cybershield Tech" />

    <!-- Meta Robots -->
    <meta name="robots" content="index, follow" />

    <!-- Open Graph Meta for Social Sharing -->
    <meta property="og:title" content="Cybershield Tech - Premier Cybersecurity Solutions" />
    <meta property="og:description" content="Cybershield Tech provides comprehensive cybersecurity services designed to protect your business from various cyber risks. Partner with us to secure your digital assets." />
    <meta property="og:image" content="https://yourwebsite.com/images/og-image.jpg" />
    <meta property="og:url" content="https://yourwebsite.com" />
    <meta property="og:type" content="website" />

    <!-- Twitter Card Meta -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="Cybershield Tech - Premier Cybersecurity Solutions" />
    <meta name="twitter:description" content="Enhance your business's security with expert cybersecurity solutions from Cybershield Tech. Our dedicated team ensures your data remains safe from cyber threats." />
    <meta name="twitter:image" content="https://yourwebsite.com/images/twitter-card-image.jpg" />

    <!-- Viewport Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Canonical Link -->
    <link rel="canonical" href="https://yourwebsite.com" />

    <!-- Favicon -->
    <link rel="icon" href="https://yourwebsite.com/favicon.ico" />
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/logo/logo.png">

    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/odometer.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/slick.css">
    <link rel="stylesheet" href="assets/css/default.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>

<body>

    <!-- Preloader -->
    <!-- <div id="preloader">
        <div id="loading-center">
            <div id="loading-center-absolute">
                <div class="object" id="object_one"></div>
                <div class="object" id="object_two"></div>
                <div class="object" id="object_three"></div>
            </div>
        </div>
    </div> -->
    <!-- Preloader End -->

    <!-- Scroll-to-top Button -->
    <button class="scroll-top scroll-to-target" data-target="html">
        <i class="fas fa-angle-up"></i>
    </button>
    <!-- Scroll-to-top End -->

    <!-- Header Area -->
    <header>
        <div id="sticky-header" class="menu-area transparent-header">
            <div class="container custom-container">
                <div class="row">
                    <div class="col-12">
                        <div class="mobile-nav-toggler"><i class="fas fa-bars"></i></div>
                        <div class="menu-wrap">
                            <nav class="menu-nav">
                                <div class="logo">
                                    <a href="index" style="display: flex;align-items: center; justify-content: center; font-weight: bolder; font-size: 30px; color: white;">
                                        <img src="assets/img/logo/logo.png"
                                            alt="Cybershield Tech Logo"
                                            style="filter:brightness(60%)"></a>
                                </div>
                                <div class="navbar-wrap main-menu d-none d-lg-flex">
                                    <ul class="navigation">
                                        <li class="active menu-item-has-children"><a href="./">Home</a></li>
                                        <li><a href="about-us">About Us</a></li>
                                        <li class="menu-item-has-children"><a href="#">Services</a>
                                            <ul class="sub-menu">
                                                <li><a href="services">Our Services</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item-has-children"><a href="course">Courses</a></li>
                                        <li><a href="contact">Contact Us</a></li>
                                    </ul>
                                </div>
                                <div class="header-social">
                                    <ul>
                                        <li><a href="#"><i class="flaticon-facebook"></i></a></li>
                                        <li><a href="#"><i class="flaticon-twitter"></i></a></li>
                                        <li><a href="#"><i class="flaticon-linkedin"></i></a></li>
                                    </ul>
                                </div>
                                <div class="offcanvas-btn">
                                    <a href="#"><img src="assets/img/icons/dots.png" alt="Menu Icon"></a>
                                </div>
                            </nav>
                        </div>
                        <!-- Mobile Menu -->
                        <div class="mobile-menu">
                            <nav class="menu-box">
                                <div class="close-btn"><i class="fas fa-times"></i></div>
                                <div class="nav-logo"><a href="index"><img src="assets/img/logo/logo.png" alt="Cybershield Tech Logo" title=""></a></div>
                                <div class="menu-outer">
                                    <!-- Menu Will Be Dynamically Generated Here -->
                                </div>
                                <div class="social-links">
                                    <ul class="clearfix">
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li><a href="#"><i class="fab fa-youtube"></i></a></li>
                                    </ul>
                                </div>
                            </nav>
                        </div>
                        <div class="menu-backdrop"></div>
                        <!-- End Mobile Menu -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Offcanvas Menu -->
        <div class="offCanvas-wrap">
            <div class="offCanvas-toggle"><img src="assets/img/icons/cross.svg" alt="Close Icon"></div>
            <div class="offCanvas-body">
                <div class="offCanvas-content">
                    <h3 class="title">Digital Safety <span>Starts Here</span> for Personal and Commercial Needs</h3>
                    <p>We provide tailored solutions to meet your cybersecurity needs, ensuring comprehensive protection against cyber threats.</p>
                </div>
                <div class="offcanvas-contact footer-contact-info">
                    <h4 class="number">+234 904519 3779 <br /> +91 848484 4985 </h4>
                    <h4 class="email">info@cybershieldtech.net</h4>
                    <p>Block 15, Rd 34 Victoria <br> Garden City Ikota Aja Lagos.</p>
                    <ul class="footer-social list-wrap">
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="offCanvas-overlay"></div>
        <!-- Offcanvas End -->
    </header>
    <!-- Header Area End -->